This is an assignment where we try to add some jQuery to our HTML/CSS website.

