$(document).ready(function(){
    $('#ninja0').click(function(){
        $("#ninja0").attr("src", "cat0.png");
    });

     $('#ninja1').click(function(){
        $("#ninja1").attr("src", "cat1.png");
    });

     $('#ninja2').click(function(){
        $("#ninja2").attr("src", "cat2.png");
    });
    
     $('#ninja3').click(function(){
        $("#ninja3").attr("src", "cat3.png");
    });

     $('#ninja4').click(function(){
        $("#ninja4").attr("src", "cat4.png");
    });
})