This is a project where we're tasked to make a pokedex with the pokemon API. 

